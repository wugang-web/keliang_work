host = 'localhost'
num_sensors = 10
table_names = ['sin_data_500Hz', 'sin_data_1000Hz', 'sin_data_100Hz',
               'sin_data_500Hz', 'sin_data_1000Hz', 'sin_data_100Hz',
               'sin_data_500Hz', 'sin_data_1000Hz', 'sin_data_100Hz',
               'sin_data_500Hz']
